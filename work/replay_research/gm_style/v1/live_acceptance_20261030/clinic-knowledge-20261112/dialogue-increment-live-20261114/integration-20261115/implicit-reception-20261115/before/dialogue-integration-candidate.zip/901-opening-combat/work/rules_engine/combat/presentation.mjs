import {equipmentStateSummary,instanceArmor} from '../equipment-state.mjs';
import {projectionView,projectionAppearance} from '../resource-projections.mjs';
import {hydrateBattleActors} from './state-view.mjs';
import {mapView,canObserve,distance,vertices,contains,elevationAt} from './map.mjs';
import {ABILITIES} from './catalog.mjs';
import {COMMON_ACTIONS} from './common-actions.mjs';
import {panel} from './engine.mjs';
import {equipment} from './mechanics.mjs';
import {decisionContext} from './runtime.mjs';
import {statusLevel,lifeStatus} from '../core.mjs';

const DAMAGE_TYPE_NAMES={B:'冲击',L:'严重',A:'恶性'};

// The player's explicit consequence receipt is assembled after narration. It
// never gives the narrator private opponent figures or asks it to infer damage.
export function ownImpactReport(root,{afterRevision=0,playerId='player'}={}) {
  const actor=root.actors[playerId];if(!actor)return '';
  const damage={B:0,L:0,A:0},changes=[],changedTypes=new Set();
  let before,hasNewPlayerSnapshot=false,grappleInBatch=false,hasResolvedPlayerSnapshot=false,hasPendingPlayerSnapshot=false;
  const operations=Object.values(root.operations).filter(o=>Array.isArray(o.summary?.result?.damage)&&o.summary.result.after?.participants)
    .sort((a,b)=>a.summary.revision-b.summary.revision);
  for(const op of operations) {
    const r=op.summary.result,after=r.after?.participants.find(a=>a.id===playerId);
    if(op.summary.revision>afterRevision) {
      for(const hit of [...r.damage,...(r.opportunities??[]).flatMap(x=>x.damage)])
        if(hit.targetId===playerId&&Object.hasOwn(damage,hit.severity))damage[hit.severity]+=hit.actualDamage;
      if(after) {
        hasNewPlayerSnapshot=true;grappleInBatch||=Boolean(before?.grapple||after.grapple);
        hasPendingPlayerSnapshot=Boolean(r.after.awaiting);
        if(!hasPendingPlayerSnapshot)hasResolvedPlayerSnapshot=true;
        const oldState={...actor.state,statuses:before?.statuses??[]},newState={...actor.state,statuses:after.statuses};
        for(const type of new Set([...oldState.statuses,...newState.statuses].map(s=>s.type))) {
          const old=statusLevel(oldState,type),now=statusLevel(newState,type);
          if(old.points!==now.points) {
            changedTypes.add(type);changes.push(now.points===0?`${type}解除`:
              `${type}${old.points?`由${old.points}变为${now.points}点`:`新增${now.points}点`}${now.severe?'（严重）':''}`);
          }
        }
        const penalty=lifeStatus({...actor.state,health:after.health}).woundPenalty;
        const previous=before?lifeStatus({...actor.state,health:before.health}).woundPenalty:0;
        if(penalty>previous)changes.push(`伤势减值现为${penalty}点`);
      }
    }
    if(after)before=after;
  }
  const injuries=Object.entries(damage).filter(([,n])=>n>0).map(([s,n])=>`${n}点${DAMAGE_TYPE_NAMES[s]}伤害（${n}${s}）`);
  const parts=[...(injuries.length?[`受到${injuries.join('、')}`]:[]),...changes];
  const reportsGrapple=hasNewPlayerSnapshot&&Boolean(actor.state.grapple||grappleInBatch);
  if(reportsGrapple) {
    if(!injuries.length)parts.unshift('本次未受到伤害');
    const state=actor.state.grapple?(actor.state.grapple.pressed?'已压制（仍在擒抱中）':'擒抱中（未压制）'):'已解除';
    parts.push(`当前擒抱状态：${state}`);
  }
  if(hasResolvedPlayerSnapshot&&!hasPendingPlayerSnapshot) {
    if(!injuries.length&&!reportsGrapple)parts.unshift('本次无伤害');
    if(!changedTypes.size&&!reportsGrapple)parts.push('无新增状态');
  }
  if(parts.length) {
    const current={...actor.state,statuses:before?.statuses??actor.state.statuses};
    const remaining=[...new Set(current.statuses.map(s=>s.type))].filter(type=>!changedTypes.has(type))
      .map(type=>({type,...statusLevel(current,type)})).filter(s=>s.points>0)
      .map(s=>`${s.type}${s.points}点${s.severe?'（严重）':''}`);
    if(remaining.length)parts.push(`当前负面状态：${remaining.join('、')}`);
  }
  return parts.length?`**${actor.name}本次结算：** ${parts.join('；')}。`:'';
}

const brightArms=mode=>({empty:'双手空着',bow:'旧长弓在手',longknife:'精致长刀在手',dagger:'缴获匕首在手'})[mode];
const visibleArms=a=>a.state.combatManeuvers?.weaponUnavailable?'当前徒手，主手没有可用武器':a.state.equippedWeaponId&&a.state.possessions?.items?.some(i=>i.id===a.state.equippedWeaponId&&i.held)?`${equipment(a).weapon.name??'实际武器'}在手`:a.kind==='mireya'?(a.weaponMode==='club'?'包毡短棍在手，竞技弓不处于射击姿势':`双手持竞技弓${a.loaded?'，已上箭':'，未上箭'}，包毡短棍收在腰侧`):a.ruleset==='opening-20261022'?(a.kind==='bright'?brightArms(a.weaponMode)??'当前持握未确认':a.kind==='huang'?`${a.visibleArms}${a.sheathed?'仍在鞘':'已在手'}`:a.visibleArms):a.kind==='jiang'?'徒手，以拳掌应战':a.kind==='huang'?`狮子王太刀${a.sheathed?'在鞘':'出鞘'}`:
  a.kind==='yulin'?`弃风长剑${a.sheathed?'在鞘':'在手'}`:a.kind==='bright'?'苍穹长弓':a.kind==='lotus'?'灵兽，以爪牙应战':'以已出现的装备为准';
function condition(state,actor) {
  const life=lifeStatus(state).state;
  if(life==='dead')return '倒地，已无生命迹象，不能对话或自主行动';
  if(life==='unconscious'&&!actor?.diehard)return '倒地失去意识，不能对话或自主行动';
  return state.health.intact>0?(state.health.B+state.health.L+state.health.A>0?'可见受伤':'未见伤势'):'倒地';
}

// Observable execution, not the private ability text (which includes budgets
// and defense figures). Preparing a guard does not itself resolve an attack.
const preparations={
  zheng:{execution:'收束剑路，以长剑护持身前，转入挡接来袭的守势',outcome:'守势的防护准备已经成立'},
  block:{execution:'以当前格挡手段护住自身，准备挡接来袭',outcome:'格挡的防护准备已经成立'},
  fistQi:{execution:'将气运至拳掌，凝聚后续出拳的劲力',outcome:'拳气准备成立，尚未出拳'},
  breakBody:{execution:'运转破身拳法门，将劲力收于拳掌',outcome:'破身拳运功准备成立，尚未出拳'},
  brace:{execution:'稳住持盾姿态，运气准备承接下一次来袭',outcome:'本次防护准备成立，尚未挡接来袭'},
  calibrate:{execution:'停住脚步，持续观察目标并拉稳弓弦',outcome:'完成定点校准准备，尚未放箭'},
  drawClub:{execution:'停止双手持弓，腾出一手抽取腰侧短棍',outcome:'短棍已在手，尚未另行准备格挡'},
  readyBow:{execution:'将短棍收回腰侧，重新双手持弓',outcome:'恢复持弓姿势，是否已上箭沿实际状态'},
};

// This allowlist is the boundary between the private rules save and prose.
// Do not send stateResult, decisionContext, or operation summaries to the narrator.
export function publicScene(root,{afterRevision=0,playerId='player'}={}) {
  const b=hydrateBattleActors(root.battle,root.actors);
  const actors=Object.entries(b.actors).filter(([,a])=>canObserve(b,a,playerId));
  const operations=Object.values(root.operations).filter(o=>Array.isArray(o.summary?.result?.damage)&&o.summary.result.after?.participants)
    .sort((a,b)=>a.summary.revision-b.summary.revision);
  const declared=new Map(),events=[];let hasAttack=false,hasPending=false,hasStatusEffect=false;
  for(const [index,op] of operations.entries()) {
    const r=op.summary.result,c=JSON.parse(op.signature);
    if(c.abilityId&&c.abilityId!=='react')declared.set(`${c.actorId}/${c.abilityId}`,c);
    if(op.summary.revision<=afterRevision)continue;
    const beforeSnapshot=operations[index-1]?.summary.result.after,before=beforeSnapshot?.participants;
    const visibleAt=(participants,ids)=>{
      if(ids)return ids.filter(id=>b.actors[id]).map(id=>[id,b.actors[id].name]);
      const snapshot={...b,actors:Object.fromEntries(Object.entries(b.actors).map(([id,a])=>[id,{...a,position:participants?.find(p=>p.id===id)?.position??a.position}]))};
      return Object.entries(snapshot.actors).filter(([,a])=>canObserve(snapshot,a,playerId)).map(([id,a])=>[id,a.name]);
    };
    const afterSeen=new Map(visibleAt(r.after.participants,r.after.visibleTo?.[playerId])),seen=new Map([...visibleAt(before,beforeSnapshot?.visibleTo?.[playerId]),...afterSeen]);
    if(!seen.has(r.actorId)||['enter','leave','end','parameters','react','map','mapUpdate'].includes(r.abilityId))continue;
    if(r.after.awaiting&&op.summary.revision!==root.revision)continue;
    const command=c.abilityId===r.abilityId?c:declared.get(`${r.actorId}/${r.abilityId}`)??{};
    const pendingMovement=Boolean(r.after.awaiting&&['move','step','charge'].includes(r.abilityId));
    if(r.after.awaiting)hasPending=true;
    if(r.attack||r.opportunities?.length)hasAttack=true;
    const event={actor:seen.get(r.actorId),action:b.actors[r.actorId]?.abilityDefinitions?.[r.abilityId]?.name??ABILITIES[r.abilityId]?.name??'行动',
      arms:visibleArms(b.actors[r.actorId]),
      status:r.after.awaiting?'pending':'resolved',
      ...(seen.has(command.targetId)?{target:seen.get(command.targetId)}:{})};
    if(pendingMovement) {
      event.execution='准备离开近战威胁范围，移动被待处理的借机反应暂停';
      event.outcome=b.pending?.kind==='opportunity'
        ?'仍在原站位，尚未移动；等待玩家声明是否进行借机攻击'
        :'仍在原站位，尚未移动；借机攻击的命中与伤害未定，等待玩家声明如何防御';
    }
    else if(r.after.awaiting)event.outcome='攻击将至，等待受击反应；尚未命中';
    else if(r.attack)event.outcome=r.damage.some(x=>x.actualDamage>0)?'造成伤势':r.attack.amount>0?'攻击被防护化解':'未能命中';
    else if(preparations[r.abilityId])Object.assign(event,preparations[r.abilityId]);
    else event.outcome='已执行';
    if(!r.after.awaiting&&b.actors[r.actorId]?.kind==='bright'&&b.actors[r.actorId]?.ruleset==='opening-20261022') {
      if(r.abilityId==='stowWeapon'){event.arms=brightArms('empty');event.outcome='已收起当前武器，双手空着';}
      if(r.abilityId==='readyWeapon'&&brightArms(command.weapon)){event.arms=brightArms(command.weapon);event.outcome=`已取出武器，${event.arms}`;}
    }
    if(!r.after.awaiting){
      const ownStatus=(r.statuses??[]).filter(s=>s.targetId===playerId&&s.applied===true&&s.remaining>0)
        .map(s=>s.type??({hypnotize:'魅惑',tentacles:'麻痹'})[r.abilityId]).filter(Boolean);
      if(ownStatus.length){event.outcome=`${seen.get(playerId)??'御临风'}已受到${[...new Set(ownStatus)].join('、')}影响`;hasStatusEffect=true;}
    }
    if(r.preActionCheck?.allowed===false)event.outcome='行动前检定未通过，所声明动作没有执行';
    if(r.posture)event.outcome=r.posture==='prone'?'已伏地，仍在原处':'已起身，仍在原处';
    if(r.itemUse)event.outcome=r.itemUse.operation==='draw'?`已拔出${r.itemUse.name}并持握为当前武器；没有攻击，也没有移动`:r.itemUse.operation==='pickup'?`已从地面拾起${r.itemUse.name}并持握为当前武器；此次拾取没有攻击`:`已取出${r.itemUse.name}，没有自动使用或消耗该物品`;
    if(['bullRush','counterRush'].includes(r.abilityId)&&!r.after.awaiting){
      event.execution='以身体冲撞目标';
      event.outcome=!r.contest?.won?'冲撞被抵挡或避让，目标未被击退或击倒':r.knockdown?'冲撞使目标倒地':r.forcedMovement?.blocked?'冲撞对抗成功，但击退路线受阻，目标没有位移':'冲撞将目标推离原位';
      if(r.forcedMovement&&seen.has(r.forcedMovement.targetId))event.displacement={actor:seen.get(r.forcedMovement.targetId),travelMeters:r.forcedMovement.length};
    }
    if(r.abilityId==='grapple'&&!r.after.awaiting)event.outcome=r.grapple?.success?'已建立擒抱，抓住了目标；没有造成伤害':r.contact?.total>0?'接触到了目标，但擒抱对抗未成功；没有抓住或造成伤害':'未能接触抓住目标，没有造成伤害';
    if(!r.after.awaiting){
      if(r.abilityId==='feint')event.outcome=r.contest?.won?'虚招奏效，获得针对该目标的下次近战机会；尚未攻击或造成伤害':'对方没有被虚招骗过，未造成伤害';
      if(r.abilityId==='trip')event.outcome=r.knockdown?'绊摔成功，目标倒地，未造成伤害':r.flightTrip?'绊摔使空中目标飞行受阻，未使其落地或造成伤害':'绊摔未成功，目标没有倒地';
      if(r.abilityId==='disarm'||r.abilityId==='sunder')event.outcome=r.disarmed?`${r.disarmed.name}已脱手落地，持有人未受伤`:r.equipmentDamage?`${r.equipmentDamage.name}${r.equipmentDamage.destroyed?'已经损毁':r.equipmentDamage.structuralDamage>0?'受到结构损伤':'未被突破硬度'}，持有人未受伤`:'目标装备未被击落或损坏，持有人未受伤';
    }
    // The attack profile belongs to this shot; the final actor may already
    // have spent its arrow or switched weapons by the time prose is rendered.
    if(r.attack&&['bright','mireya'].includes(b.actors[r.actorId].kind)&&r.attack.range>b.actors[r.actorId].reach) {
      event.arms='本次攻击使用的长弓与箭矢';
      event.execution=r.after.awaiting?'持弓对准目标，箭矢来势已显现，命中与伤害尚未结算':'松弦放箭，箭矢沿本次射击路线飞向目标';
    }
    if(r.abilityId==='shieldPush'&&!r.after.awaiting) {
      event.execution='以盾面抵近对手，试图将其推离当前位置';
      event.outcome=r.forcedMovement?'盾推成功，将对手推开；推人者保持原位':r.contest?.won?'对抗占优，但路线或落点受阻，双方站位未变':'盾推被抵住，双方站位未变';
      if(r.forcedMovement&&seen.has(r.forcedMovement.targetId))event.displacement={actor:seen.get(r.forcedMovement.targetId),travelMeters:r.forcedMovement.length};
    }
    if(r.abilityId==='concede')event.outcome='主动认输，本场停止交锋';
    if(r.recovery) {
      event.action=`服用${r.recovery.medicine}`;event.execution=`服下已声明的${r.recovery.medicine}`;
      event.outcome=r.recovery.pending.some(p=>p.medicine===r.recovery.medicine)?'药物已服用，伤势和异常状态没有改善；药效等待所需的完整休息，不得提前描述伤痛减轻或恢复':'已完成本次用药的即时效果';
      event.recovery=r.recovery.changes.filter(x=>x.healed||x.restored||x.removed).map(x=>({source:x.source,...(x.healed?{healed:x.healed,severity:x.severity}:{}),...(x.restored?{resource:x.resource,restored:x.restored}:{}),...(x.removed?{status:x.status,removed:x.removed}:{})}));
    }
    if(r.terrain) {
      event.target=r.terrain.label;event.outcome=r.terrain.outcome;
      event.execution=r.abilityId==='door'?(r.terrain.open?'推开眼前的门':'将眼前的门关上'):'以当前武器攻击所声明的障碍段';
    }
    const damage=[...r.damage,...(r.opportunities??[]).flatMap(x=>x.damage)];
    // Project only the player's actual, post-conversion injury types. Nested
    // opportunities may already be resolved while the parent action is pending.
    const settledDamage=[...(!r.after.awaiting?r.damage:[]),...(r.opportunities??[]).flatMap(x=>x.damage)];
    const playerDamageTypes=Object.keys(DAMAGE_TYPE_NAMES).filter(type=>settledDamage.some(x=>x.targetId===playerId&&x.actualDamage>0&&x.severity===type));
    if(playerDamageTypes.length&&seen.has(playerId))event.playerDamageTypes=playerDamageTypes.map(type=>DAMAGE_TYPE_NAMES[type]);
    const affectedIds=[...new Set(damage.filter(x=>x.actualDamage>0&&seen.has(x.targetId)).map(x=>x.targetId))];
    event.affected=affectedIds.map(id=>seen.get(id));
    if(event.affected.length) {
      event.consequence=`${event.affected.join('、')}确实受伤，防御未完全化解伤害；必须写出受创，不得写成完全挡住或无伤。`;
      // Compare this event's snapshots, not the final scene: a later movement
      // remains a separate event and cannot turn an earlier hit into knockback.
      const stationary=affectedIds.filter(id=>{
        const from=before?.find(x=>x.id===id)?.position,to=r.after.participants.find(x=>x.id===id)?.position;
        return from&&to&&from.length===to.length&&from.every((value,i)=>value===to[i]);
      }).map(id=>seen.get(id));
      if(stationary.length)event.consequence+=`${stationary.join('、')}此次受击时原地受创，站位未变。`;
    }
    if(!r.after.awaiting){
      const held=[...new Set((r.grapples??[]).filter(g=>g.success&&seen.has(g.targetId)).map(g=>seen.get(g.targetId)))];
      if(held.length)event.consequence=`${event.consequence??''}${held.join('、')}已被夹住。`;
      // Use this action's saved state, never a later hold/suppression outcome.
      const grappleIds=[...new Set([...(r.grapples??[]).filter(g=>g.success).map(g=>g.targetId),
        ...(['grapple','pressGrip'].includes(r.abilityId)&&r.grapple?[command.targetId]:[])])];
      const grappleStates=grappleIds.filter(id=>seen.has(id)).flatMap(id=>{
        const saved=r.after.participants.find(p=>p.id===id)?.grapple;
        return typeof saved?.pressed==='boolean'?[{actor:seen.get(id),state:saved.pressed?'已压制':'擒抱中，未压制'}]:[];
      });
      if(grappleStates.length)event.grappleStates=grappleStates;
    }
    if(['move','step','charge'].includes(r.abilityId)&&!pendingMovement) {
      const to=r.after.participants.find(x=>x.id===r.actorId)?.position;
      const from=r.movement?.from??before?.find(x=>x.id===r.actorId)?.position;
      const observer=r.after.participants.find(x=>x.id===playerId)?.position;
      if(!afterSeen.has(r.actorId)){event.outcome='移入遮挡之后，离开视线；不公开遮挡后的落点';}
      if(afterSeen.has(r.actorId)&&from&&to)event.travelMeters=Math.round((r.movement?.length??distance(from,to))*10)/10;
      if(r.movement&&b.map) {
        const path=r.movement.path.filter(position=>r.actorId===playerId||canObserve({...b,actors:{...b.actors,[playerId]:{...b.actors[playerId],position:observer}}},{...b.actors[r.actorId],position},playerId));
        const known=b.map.features.filter(f=>!f.hiddenFrom?.includes(playerId));
        event.route={around:known.filter(f=>['obstacle','door'].includes(f.kind)&&path.slice(1,-1).some(p=>vertices(f).some(v=>distance(p,v)<.5))).map(f=>f.label),
          through:known.filter(f=>!['obstacle','door'].includes(f.kind)&&path.some(p=>contains(p,f,{boundary:false}))).map(f=>f.label)};
      }
      if(r.actorId===playerId)event.relativePosition=r.after.participants.filter(p=>p.id!==playerId&&afterSeen.has(p.id)).map(p=>`${seen.get(p.id)}与御临风相距${Math.round(distance(to,p.position)*10)/10}米`);
      if(r.actorId===playerId)event.outOfSight=[...seen.keys()].filter(id=>id!==playerId&&!afterSeen.has(id)).map(id=>seen.get(id));
      if(afterSeen.has(r.actorId)&&observer&&from&&r.actorId!==playerId){event.direction=distance(to,observer)>distance(from,observer)?'远离御临风':'靠近御临风';event.distanceToPlayer=Math.round(distance(to,observer)*10)/10;}
    }
    if(r.opportunities)event.reactions=r.opportunities.filter(x=>seen.has(x.actorId)).map(x=>({actor:seen.get(x.actorId),
      action:'借机攻击',arms:visibleArms(b.actors[x.actorId]),timing:'离开近战范围之前，随后才完成移动',outcome:x.damage.some(d=>d.actualDamage>0)?'造成伤势':'未造成伤势'}));
    if(r.responses?.length)event.responses=r.responses.filter(x=>seen.has(x.targetId)).map(x=>({
      actor:seen.get(x.targetId),method:x.method??(x.guarded?'已就绪的主动格挡参与本击防御':'本击仅使用基础及被动防护，没有使用主动格挡'),
    }));
    events.push(event);
  }
  const origin=(b.actors[playerId]??b.observers?.[playerId])?.position;
  const terrain=a=>b.map?{terrain:{elevation:elevationAt(b.map,a.position),areas:b.map.features
    .filter(f=>!f.destroyed&&!f.hiddenFrom?.includes(playerId)&&contains(a.position,f)).map(f=>f.label)}}:{};
  const nearby=b.map?.features.filter(f=>!f.hiddenFrom?.includes(playerId)).map(f=>({f,d:origin?(contains(origin,f)?0:Math.min(...vertices(f).map(p=>distance(p,origin)))):Infinity})).filter(x=>x.d<=10).sort((a,b)=>a.d-b.d).slice(0,3).map(x=>x.f.label);
  return {events,projections:projectionView(b,playerId),vagueObservations:mapView(b,playerId)?.vagueObservations??[],...(hasPending?{interaction:'本段含尚未结算的行动；只展开已经显现的准备或来势，停在所列等待处，不预写其移动、命中或伤害结果。'}:!hasAttack&&!hasStatusEffect?{interaction:'本段仅发生已列出的移动、准备或恢复等行动，双方未发生攻击或挡接。'}:{}),setting:b.map?{name:b.map.title,nearbyLandmarks:nearby,...(b.arena?{nature:'实体练习场；终止是按约停手，不产生自动声光信号、光标或虚拟投影。'}:{})}:b.scenario,participants:actors.map(([id,a])=>({id,name:projectionAppearance(b,id,playerId)?.name??a.name,location:id===playerId?'你所在的位置':origin?`与你相距${Math.round(distance(a.position,origin)*10)/10}米`:'场上可见位置',...terrain(a),...(projectionAppearance(b,id,playerId)?{appearance:projectionAppearance(b,id,playerId).description}:{condition:condition(root.actors[id].state,a),arms:visibleArms(a)})})),
    ...(b.resolution?{resolution:b.resolution.kind==='refereeStop'
      ?{...b.resolution,text:'按本场预告的终止条件，练习结束；现有伤势与资源保留。'}:b.resolution}:{}),
    phase:b.mode==='story'?'战斗结束':b.pending?.kind==='counterRush'?'等待反冲选择':b.pending?.kind==='opportunity'?'等待玩家借机攻击声明':b.pending?.awaiting===playerId?'等待玩家受击反应':b.activeId===playerId?'等待玩家继续行动':'场上行动',
    ...(b.status==='finished'?{winners:actors.filter(([,a])=>a.team===b.winner).map(([,a])=>a.name)}:{})};
}

export function playerDeclarationContext(b,revision,playerId='player') {
  const safe=structuredClone(b);
  // Even explicitly shared ally stats are private under this campaign's rule.
  safe.knowledge={...safe.knowledge,[playerId]:Object.fromEntries(Object.entries(safe.knowledge?.[playerId]??{}).map(([id,k])=>[id,{...k,stats:false}]))};
  const context=decisionContext(safe,revision);
  const itemIds=new Set(context.legalOptions.filter(c=>['takeItem','drawWeapon'].includes(c.abilityId)).map(c=>c.itemId));
  const items=(safe.actors[playerId].state.possessions?.items??[]).filter(i=>itemIds.has(i.id)).map(i=>({
    id:i.id,ownerId:playerId,name:i.name,...(i.aliases?{aliases:i.aliases}:{}),access:i.access,held:i.held}));
  for(const c of context.legalOptions.filter(c=>c.abilityId==='pickupWeapon')){
    const i=safe.actors[c.fromActorId].state.possessions.items.find(i=>i.id===c.itemId);
    items.push({id:i.id,fromActorId:c.fromActorId,name:i.name,...(i.aliases?{aliases:i.aliases}:{}),location:'ground',position:i.position,held:false});
  }
  if(items.length)context.items=items;
  context.abilities={...context.abilities,...Object.fromEntries([...safe.actors[playerId].abilities,'door','destroy','firstAid','escapeGrip','pressGrip','grappleAttack','ringStore','ringRetrieve','mechanism'].map(id=>[id,safe.actors[playerId].abilityDefinitions?.[id]??ABILITIES[id]]))};
  return context;
}

const slotNames={standard:'标准',move:'移动',swift:'迅捷',reflex:'反射'};
const slots=o=>Object.entries(o??{}).filter(([,n])=>n>0).map(([k,n])=>`${slotNames[k]??k}×${n}`).join('、')||'无';
export function combatActionReport(root,{afterRevision=0,playerId='player'}={}){
 if(!root.battle)return '';
 const lines=[],ops=Object.values(root.operations).filter(o=>o.summary?.result?.after?.participants).sort((a,b)=>a.summary.revision-b.summary.revision);
 for(const [index,op] of ops.entries()){
  if(op.summary.revision<=afterRevision)continue;
  const r=op.summary.result,a=root.actors[r.actorId];if(!a||['enter','leave','parameters','map','mapUpdate','react'].includes(r.abilityId)||r.abilityId==='end'&&r.actorId!==playerId)continue;
  if(r.after.awaiting&&op.summary.revision!==root.revision)continue;
  const seen=r.after.visibleTo?.[playerId]??[];
  if(r.actorId!==playerId&&!seen.includes(r.actorId)){
   // Preserve the witnessed departure, not the actor's later hidden actions.
   const beforeSeen=ops[index-1]?.summary.result.after.visibleTo?.[playerId]??[];
   if(r.abilityId==='burrow'&&!r.after.awaiting&&beforeSeen.includes(r.actorId)){
    const label=root.battle.actors[r.actorId]?.abilityDefinitions?.[r.abilityId]?.name??'土遁入地';
    lines.push(`${a.name}｜${label}`,'状态：已入土，离开视线；地下位置与后续行动不可见。');
   }
   continue;
  }
  for(const opportunity of r.opportunities??[]){
   if(opportunity.actorId!==playerId&&!seen.includes(opportunity.actorId))continue;
   const attacker=root.actors[opportunity.actorId],target=root.actors[r.actorId];
   if(!attacker)continue;
   const outcome=opportunity.damage?.some(d=>d.actualDamage>0)?'造成伤害':opportunity.attack?.amount>0?'未造成实际伤害':opportunity.attack?'未命中':'已结算';
   lines.push(`${attacker.name}｜借机攻击${target&&(r.actorId===playerId||seen.includes(r.actorId))?` → ${target.name}`:''}`,`状态：${outcome}`);
  }
  const command={...JSON.parse(op.signature),...(r.receipt?.targetId?{targetId:r.receipt.targetId}:{})},target=root.actors[command.targetId];
  const label=root.battle.actors[r.actorId]?.abilityDefinitions?.[r.abilityId]?.name??ABILITIES[r.abilityId]?.name??'已记录行动';
  lines.push(`${a.name}｜${label}${target&&(command.targetId===playerId||seen.includes(command.targetId))?` → ${target.name}`:''}`);
  if(r.after.awaiting){lines.push(root.battle.pending?.kind==='paid-movement'?'状态：跳跃检定与本段移动动作已支付；实际轨迹等待借机反应，未完成位移。':'状态：待裁定；攻击、移动及对应消耗尚未执行。');continue;}
  const q=r.receipt;
  if(r.actorId===playerId&&q){
   lines.push(`动作消耗：${slots(q.actions)}`);
   const ordinary=COMMON_ACTIONS[r.abilityId]||['strike','move','step','block','fullDefense','reload','medicine','door','destroy','firstAid','escapeGrip','pressGrip','grappleAttack','jump','continueJump','end'].includes(r.abilityId);
   lines.push(`技能／招式：${ordinary?'未额外使用特殊技能':label}`);
   const use=[...(q.weapon?[`使用${q.weapon}`]:[]),...(q.itemUse?[`${q.itemUse.operation==='pickup'?'拾起并持握':'取出'}${q.itemUse.name}`]:[]),...q.items.map(x=>`${x.name}×${x.quantity}`)];
   lines.push(`装备／物品：${use.join('；')||'无使用或消耗'}`);
   const resources=[...q.resources.map(x=>`${x.name}×${x.quantity}`),...(q.willSpent?[`意志×${q.willSpent}`]:[])];
   lines.push(`资源消耗：${resources.join('、')||'无'}`,`主动移动：${q.movement}米`,`剩余动作：${slots(q.remaining)}`);
  }else if(r.movement)lines.push(`可见移动：${r.movement.length}米`);
  for(const response of r.responses??[])if(response.targetId===playerId||seen.includes(response.targetId))lines.push(`防御（${root.actors[response.targetId]?.name??'受击者'}）：${response.method??(response.guarded?'使用已就绪的主动格挡':'基础及被动防护，未主动格挡')}`);
  const shieldSaves=r.contest?.kind==='shieldPush'?(r.saves??[]).filter(s=>s.type==='fort'):[];
  for(const save of shieldSaves)if(save.targetId===playerId||seen.includes(save.targetId))lines.push(`防御（${root.actors[save.targetId]?.name??'受击者'}）：强韧抵抗`);
  if(!(r.responses?.length)&&!shieldSaves.length)lines.push(['block','zheng','fullDefense','brace'].includes(r.abilityId)?'防御：已完成防护准备，尚不代表挡住一次攻击。':'防御：本动作没有防御结算。');
  if(r.forcedMovement&&(r.forcedMovement.targetId===playerId||seen.includes(r.forcedMovement.targetId)))lines.push(`被迫位移（${root.actors[r.forcedMovement.targetId]?.name??'目标'}）：${r.forcedMovement.length}米${r.forcedMovement.blocked?'（受阻）':''}`);
  if(r.disarmed)lines.push(`装备结果：${r.disarmed.name}已脱手落地。`);
  if(r.equipmentDamage)lines.push(`装备结果：${r.equipmentDamage.name}${r.equipmentDamage.destroyed?'已损毁':r.equipmentDamage.structuralDamage>0?'已受损':'未突破硬度'}。`);
  if(r.counterOffer)lines.push('此前冲撞已结算，等待抵挡者选择是否反冲。');
  lines.push(`状态：${r.preActionCheck?.allowed===false?'行动前检定未通过，所声明动作未执行':r.grapple?r.grapple.success?'擒抱对抗成功':'擒抱对抗未成功':r.contact?.total===0?'未能接触抓住目标':r.contest?r.contest.won?'对抗成功':'对抗未成功':r.terrain?.kind==='damage'?r.terrain.outcome:r.attack?r.damage.some(d=>d.actualDamage>0)?'攻击已结算，造成伤害':r.attack.amount>0?'攻击已结算，未造成实际伤害':'攻击已结算，未命中':'已执行'}`);
 }
 return lines.length?`【本次战斗记录】\n${lines.join('\n')}`:'';
}

// This object is for local player UI only; it never enters a narration prompt.
export const stripLegacyOwnStatus=text=>text.replace(/<details>\s*<summary>[^<]* · 自身状态<\/summary>[\s\S]*?<\/details>/g,'').trim();

export function ownStatus(root,battle,playerId='player',fallbackActor) {
  const actor=root.actors[playerId];
  if(!actor)return null;
  const source=battle?.actors[playerId]??(fallbackActor?{...fallbackActor,...actor.combatCarry,state:actor.state}:null);
  if(!source)return null;
  const b=battle?.actors[playerId]?battle:{playerDefenseDeclarations:true,actors:{[playerId]:source}};
  const p=panel(b,playerId),intent=source.defenseIntent;
  return {name:actor.name,health:p.health,hpMax:p.hpMax,energy:p.energy,will:p.will,xp:actor.state.xp,
    ...(equipmentStateSummary(source.state)?{equipment:{...equipmentStateSummary(source.state),armorDefense:instanceArmor(source.state)?.defense}}:{}),
    attack:{dp:p.attack.dp,fixed:p.attack.fixed,cap:p.attack.cap},
    defense:p.defense.pending?{pending:true}:{total:p.defense.total,parts:p.defense.parts,extraSuccesses:p.defense.extraSuccesses},
    speed:p.speed,actions:p.actions,activeTurn:battle?.mode==='combat'&&battle.activeId===playerId,
    statuses:p.statuses,attributes:p.attributes,life:p.life,
    ...(intent?{declaredDefense:structuredClone(intent)}:{})};
}
