import { buildCharacter, requireKnownSkill } from '../../character_builder/builder.mjs';
import { effectiveAttribute, effectiveSkill, resolveGeneticUnlock, actionEligibility } from '../core.mjs';
import { initializeTestState, readTestOperation, readTestSummary,
  readTestActorState, readTestOpportunity, settleCheck, settleDirectEffect,
  settleGeneticUnlock, settleScriptedFortune, requiresEffectChoice } from '../mvu_poc/adapter.mjs';

const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const ATTRIBUTES = new Set(['力量', '敏捷', '智力', '感知', '意志', '风度']);
// Isolated demonstration only: this is an explicit scene award, not a 901
// universal roleplay bonus or a newly adopted PHB/RE resource.
const DIRECT_EFFECTS = Object.freeze({
  'demo.scene-cue': Object.freeze({ id: 'demo.scene-cue', label: '场景线索',
    source: 'isolated-demo/scene-cue', attribute: '感知', skill: '洞察',
    value: 1, duration: 'nextMatchingCheck', visibility: 'public' }),
});
const validCheck = request => record(request) && request.kind === 'check' &&
  Object.keys(request).every(k => ['kind', 'attribute', 'skill', 'sub', 'dc'].includes(k)) &&
  ATTRIBUTES.has(request.attribute) && typeof request.skill === 'string' &&
  Number.isInteger(request.dc) && request.dc >= 1 && request.dc <= 10;
const matches = (effect, request) => effect.attribute === request.attribute &&
  effect.skill === request.skill && (effect.sub ?? null) === (request.sub ?? null);
// The host confirms an adopted rule's trigger for this exact branch. Model
// requests can select the map key only, never supply this authorization.
function scriptedOpportunityReady(spec, anchor) {
  const text = value => typeof value === 'string' && value.trim().length > 0;
  const trigger = spec?.trigger;
  const condition = spec?.successCondition;
  return record(spec) && spec.authorized === true && spec.resolved === false &&
    spec.rollType === 'phb_fortune' && ['public', 'secret'].includes(spec.visibility) &&
    text(spec.sourceId) && text(spec.opportunityId) && record(condition) &&
    Object.keys(condition).every(key => key === 'minimum') &&
    Number.isInteger(condition.minimum) && condition.minimum >= 1 &&
    record(trigger) && text(trigger.id) && text(trigger.condition) && trigger.satisfied === true &&
    trigger.anchor?.chatId === anchor.chatId && trigger.anchor?.messageId === anchor.messageId &&
    trigger.anchor?.swipeId === anchor.swipeId;
}
function randomDice() {
  const dice = [];
  while (dice.length < 256) {
    const bytes = new Uint8Array(256);
    globalThis.crypto.getRandomValues(bytes);
    for (const byte of bytes) if (byte < 250 && dice.length < 256) dice.push(byte % 10 + 1);
  }
  return dice;
}

// NPC ordinary checks share the existing actor/check/commit path. The scene
// authorization and modifier catalogue come from the host, never model JSON.
export async function settleNpcCheck({ mvu, getAnchor, expectedChatId, operationId,
  request, npcContext, drawDice = randomDice } = {}) {
  const missing = () => ({ status: 'needs_input', kind: 'check', actorType: 'npc',
    missing: ['NPC检定需要完整可信人物数据及当前场景授权；未结算。'] });
  if (!record(request) || request.kind !== 'check' || typeof request.actorId !== 'string' ||
      !request.actorId || request.actorId === 'player') return missing();
  if ('opposed' in request || 'consequence' in request)
    return { status: 'deferred', kind: 'check', actorType: 'npc',
      reason: 'NPC opposed checks and additional mechanical consequences are not integrated' };
  if (Object.keys(request).some(k => !['kind', 'actorId', 'sceneId', 'triggerId', 'attribute',
    'skill', 'sub', 'dc', 'modifierIds', 'effectChoice'].includes(k)) ||
      !ATTRIBUTES.has(request.attribute) || typeof request.skill !== 'string' ||
      !Number.isInteger(request.dc) || request.dc < 1 || request.dc > 10 ||
      !Array.isArray(request.modifierIds ?? []) ||
      new Set(request.modifierIds ?? []).size !== (request.modifierIds ?? []).length) return missing();
  const opts = { mvu, getAnchor, expectedChatId };
  const anchor = getAnchor();
  if (anchor.chatId !== expectedChatId || operationId !== `gm-runtime/${expectedChatId}/${anchor.messageId}/${anchor.swipeId}`)
    return missing();
  const project = result => ({ status: result.status, kind: 'check', actorType: 'npc', operationId,
    success: result.success, fortune: result.fortune, possibleMishap: result.possibleMishap,
    consequences: 'No additional numerical consequences authorized' });
  let saved;
  try { saved = readTestOperation({ ...opts, operationId }); } catch { return missing(); }
  if (saved) {
    const old = JSON.parse(saved.signature);
    if (old.actorType !== 'npc' || JSON.stringify(old.checkInput?.npcRequest) !== JSON.stringify(request))
      return missing();
    return project({ ...saved.summary, status: 'already_applied' });
  }
  if (!record(npcContext) || !npcContext.sceneId || !npcContext.triggerId ||
      request.sceneId !== npcContext.sceneId || request.triggerId !== npcContext.triggerId ||
      !npcContext.actorIds?.includes(request.actorId) || npcContext.protagonistInvolved !== true ||
      typeof npcContext.reason !== 'string' || !npcContext.reason.trim()) return missing();
  let state, modifiers, expectedRevision;
  const trustedEffects = npcContext.trustedEffects ?? {};
  try {
    state = readTestActorState({ ...opts, actorId: request.actorId });
    requireKnownSkill(state, request.skill, request.sub);
    effectiveAttribute(state, request.attribute);
    effectiveSkill(state, request.skill, request.sub);
    const eligible = actionEligibility(state, 'free');
    if (!eligible.allowed || eligible.requiresBCheck) return missing();
    modifiers = (request.modifierIds ?? []).map(id => {
      const modifier = npcContext.modifiers?.[id];
      if (!record(modifier) || !Number.isInteger(modifier.value) ||
          typeof modifier.source !== 'string' || !modifier.source.trim() ||
          !modifier.actorIds?.includes(request.actorId) || modifier.attribute !== request.attribute ||
          modifier.skill !== request.skill || (modifier.sub ?? null) !== (request.sub ?? null))
        throw Error('Unsupported contextual modifier');
      return { id, value: modifier.value, source: modifier.source };
    });
    const effects = (state.checkEffects ?? []).filter(e => matches(e, request));
    if (effects.length > 1 || effects.some(e => JSON.stringify(e) !== JSON.stringify(trustedEffects[e.id])))
      return missing();
    const active = effects.filter(requiresEffectChoice);
    if (active.length ? !['skip', active[0].id].includes(request.effectChoice)
      : request.effectChoice !== undefined) return missing();
    expectedRevision = readTestSummary(opts).revision;
  } catch { return missing(); }
  const result = await settleCheck({ ...opts, operationId, expectedRevision,
    actorId: request.actorId, actorType: 'npc', trustedEffects,
    checkInput: { attribute: request.attribute, skill: request.skill,
      ...(request.sub === undefined ? {} : { sub: request.sub }), dc: request.dc,
      modifier: modifiers.reduce((sum, item) => sum + item.value, 0),
      ...(request.effectChoice === undefined ? {} : { effectChoice: request.effectChoice }),
      npcRequest: structuredClone(request), contextModifiers: modifiers, dice: drawDice() } });
  return project(result);
}

// Isolated replay test only. Baseline JSON must come from the trusted local card
// artifact, never from a chat variable or GM request.
export function createReplayCheckRuntime({ baseline, mvu, getAnchor, expectedChatId,
  drawDice = randomDice, geneticOpportunities = {}, scriptedOpportunities = {},
  initialGeneticLock, npcContext } = {}) {
  if (baseline?.baselineStatus !== 'APPROVED_REPLAY_BASELINE' ||
      typeof expectedChatId !== 'string' || !expectedChatId ||
      typeof getAnchor !== 'function' || typeof drawDice !== 'function')
    throw new Error('Trusted replay baseline and isolated chat required');
  const opts = { mvu, getAnchor, expectedChatId };
  const built = buildCharacter(baseline.definition, baseline.openingState.isolatedTestInitial);
  if (!built.ok) throw new Error(`Replay Builder input invalid: ${JSON.stringify(built.report)}`);
  if (initialGeneticLock !== undefined && (!record(initialGeneticLock) ||
      typeof initialGeneticLock.source !== 'string' || !initialGeneticLock.source.trim() ||
      !record(initialGeneticLock.successfulUnlocks) ||
      !Number.isInteger(initialGeneticLock.successfulUnlocks[1]) || initialGeneticLock.successfulUnlocks[1] < 0 ||
      !Number.isInteger(initialGeneticLock.highestStage) || initialGeneticLock.highestStage < 0 ||
      !Number.isInteger(initialGeneticLock.activeStage) || initialGeneticLock.activeStage < 0 ||
      (initialGeneticLock.successfulUnlocks[2] !== undefined &&
        (!Number.isInteger(initialGeneticLock.successfulUnlocks[2]) || initialGeneticLock.successfulUnlocks[2] < 0))))
    throw new Error('Explicit sourced genetic-lock history required');
  const initialPlayerState = structuredClone(built.state);
  if (initialGeneticLock !== undefined) initialPlayerState.geneticLock = structuredClone(initialGeneticLock);
  return {
    buildReport: built.report,
    directEffectOptions: Object.values(DIRECT_EFFECTS).map(effect => ({
      id: effect.id, label: effect.label, attribute: effect.attribute,
      skill: effect.skill, value: effect.value, duration: effect.duration })),
    async initialize({ openingAssumption = false } = {}) {
      if (!openingAssumption) throw new Error('Explicit replay opening assumption required');
      return initializeTestState({ ...opts, actors: {
        player: { name: baseline.definition.name, state: initialPlayerState },
      } });
    },
    read: () => readTestSummary(opts),
    scriptedOpportunityIds: () => Object.keys(scriptedOpportunities).filter(id => {
      const spec = scriptedOpportunities[id];
      return scriptedOpportunityReady(spec, getAnchor()) && !readTestOpportunity({ ...opts,
        opportunityKey: `scripted:${spec.sourceId}:${spec.opportunityId}` });
    }),
    // GM-only continuation facts. Never put these in public tool/chat metadata.
    scriptedNarrationFacts(operationId) {
      const saved = readTestOperation({ ...opts, operationId });
      if (saved?.summary?.kind !== 'scripted_fortune' || saved.summary.status !== 'applied')
        throw new Error('Saved scripted result required');
      return `已授权机会的条件${saved.mechanical.success ? '满足' : '未满足'}。` +
        '只叙述规则授权且玩家可感知的后果；不公布机会、投骰存在或机械数值，不新增数值效果。';
    },
    prepareCheck(request, choiceId) {
      if (!validCheck(request)) throw new Error('Supported ordinary check required');
      const state = readTestActorState({ ...opts, actorId: 'player' });
      requireKnownSkill(state, request.skill, request.sub);
      const skill = effectiveSkill(state, request.skill, request.sub);
      const available = (state.checkEffects ?? []).filter(effect => matches(effect, request));
      if (available.some(effect => !Object.hasOwn(DIRECT_EFFECTS, effect.id) ||
          JSON.stringify(effect) !== JSON.stringify(DIRECT_EFFECTS[effect.id])))
        throw new Error('Active effect differs from trusted template');
      if (available.length > 1) throw new Error('Multiple active effects need a separate ruling');
      const active = available.filter(requiresEffectChoice);
      if (choiceId !== undefined && choiceId !== 'skip' && !active.some(e => e.id === choiceId))
        throw new Error('Unknown player choice');
      const attribute = effectiveAttribute(state, request.attribute);
      const modifiers = available.filter(e => !active.includes(e) || e.id === choiceId)
        .map(e => ({ source: e.label, value: e.value }));
      return { publicBasis: { attribute: { name: request.attribute, value: attribute },
        mainSkill: { name: request.skill, value: skill.main },
        ...(request.sub ? { subSkill: { name: request.sub, value: skill.sub } } : {}),
        publicModifiers: modifiers,
        publicSubtotal: attribute + skill.main + skill.sub + modifiers.reduce((n, e) => n + e.value, 0),
        partial: true },
        choices: active.length ? [{ id: 'skip', label: '直接投骰／不使用' },
          ...active.map(e => ({ id: e.id, label: `${e.label} ${e.value > 0 ? '+' : ''}${e.value}DP` }))] : [] };
    },
    async settle({ operationId, request, choiceId } = {}) {
      if (request?.kind === 'check' && request.actorId !== undefined) {
        if (choiceId !== undefined) return { status: 'needs_input', missing: ['NPC检定不使用玩家选择面板'] };
        return settleNpcCheck({ ...opts, operationId, request, npcContext, drawDice });
      }
      if (record(request) && ['genetic_unlock', 'scripted_fortune'].includes(request.kind)) {
        if (typeof operationId !== 'string' || !operationId.startsWith(`gm-runtime/${expectedChatId}/`))
          throw new Error('Trusted replay operation ID required');
        if (choiceId !== undefined) return { status: 'needs_input', missing: ['Special roll has no ordinary check choice'] };
        const genetic = request.kind === 'genetic_unlock';
        const allowed = genetic ? ['kind', 'stage', 'opportunityId', 'roleplayModifier']
          : ['kind', 'opportunityId'];
        if (Object.keys(request).some(key => !allowed.includes(key)) ||
            typeof request.opportunityId !== 'string' || !request.opportunityId)
          return { status: 'needs_input', missing: ['Complete special opportunity request required'] };
        const opportunity = genetic ? geneticOpportunities[request.opportunityId]
          : scriptedOpportunities[request.opportunityId];
        if (!record(opportunity)) return { status: 'deferred', reason: 'No adopted rule for this opportunity' };
        if (!genetic && opportunity.rollType !== 'phb_fortune')
          return { status: 'deferred', reason: 'This request path requires an explicitly authorized PHB fortune opportunity' };
        if (genetic && (opportunity.visibility ?? 'public') !== 'public')
          return { status: 'deferred', reason: 'Genetic D10 checks must be public' };
        if (!genetic && opportunity.visibility === 'secret' && opportunity.rollType !== 'phb_fortune')
          return { status: 'deferred', reason: 'Only adopted fortune rolls may be secret' };
        let saved;
        try { saved = readTestOperation({ ...opts, operationId }); }
        catch (error) {
          if (/not initialized on this message branch/.test(error.message))
            return { status: 'needs_input', missing: ['隔离 MVU 人物状态尚未初始化或未承接至当前楼层'] };
          throw error;
        }
        if (saved) {
          const old = JSON.parse(saved.signature);
          const matches = genetic ? old.actorId === 'player' && old.unlockInput?.stage === request.stage &&
            old.unlockInput?.opportunity?.id === opportunity.id &&
            JSON.stringify(old.unlockInput?.roleplayModifier) === JSON.stringify(request.roleplayModifier)
            : old.spec?.sourceId === opportunity.sourceId &&
              old.spec?.opportunityId === opportunity.opportunityId;
          if (!matches) throw new Error('Operation ID already used for different input');
          return { ...saved.summary, status: 'already_applied' };
        }
        const opportunityKey = genetic ? `genetic:player:${opportunity.id}`
          : `scripted:${opportunity.sourceId}:${opportunity.opportunityId}`;
        if (readTestOpportunity({ ...opts, opportunityKey }))
          return { status: 'already_resolved', kind: request.kind, visibility: opportunity.visibility ?? 'public', operationId };
        const expectedRevision = readTestSummary(opts).revision;
        if (genetic) {
          if (request.stage === 2) return { status: 'deferred', reason: 'Second-stage state consequences are not integrated' };
          const unlockInput = { stage: request.stage, opportunity,
            specialModifiers: opportunity.specialModifiers ?? [],
            ...(request.roleplayModifier === undefined ? {} : { roleplayModifier: request.roleplayModifier }) };
          const state = readTestActorState({ ...opts, actorId: 'player' });
          const prepared = resolveGeneticUnlock(state, unlockInput);
          if (prepared.status !== 'ready') return prepared;
          return settleGeneticUnlock({ ...opts, operationId, expectedRevision, actorId: 'player',
            visibility: opportunity.visibility ?? 'public',
            unlockInput: { ...unlockInput, dice: drawDice() } });
        }
        if (opportunity.resolved === true) return { status: 'already_resolved', kind: request.kind };
        if (!scriptedOpportunityReady(opportunity, getAnchor()))
          return { status: 'needs_input', missing: ['Trusted authorization, current branch trigger and complete fortune rule required'] };
        return settleScriptedFortune({ ...opts, operationId, expectedRevision,
          spec: { ...opportunity, runtimeRequestId: request.opportunityId }, dice: drawDice() });
      }
      if (!validCheck(request) && !(record(request) && request.kind === 'direct_effect' &&
          Object.keys(request).every(k => ['kind', 'effectId'].includes(k)) &&
          Object.hasOwn(DIRECT_EFFECTS, request.effectId)))
        return { status: 'needs_input', missing: ['可执行的普通检定输入；特殊资源尚未适配'] };
      if (request.kind === 'direct_effect' && choiceId !== undefined)
        return { status: 'needs_input', missing: ['无骰效果不接受玩家检定选择'] };
      try { if (request.kind === 'check') requireKnownSkill(built.state, request.skill, request.sub); }
      catch { return { status: 'needs_input', missing: [`未知技能 ${request.skill}`] }; }
      if (typeof operationId !== 'string' || !operationId.startsWith(`gm-runtime/${expectedChatId}/`))
        throw new Error('Trusted replay operation ID required');
      let saved;
      try { saved = readTestOperation({ ...opts, operationId }); }
      catch (error) {
        if (/not initialized on this message branch/.test(error.message))
          return { status: 'needs_input', missing: ['隔离 MVU 人物状态尚未初始化或未承接至当前楼层'] };
        throw error;
      }
      if (saved) {
        const old = JSON.parse(saved.signature);
        if (request.kind === 'direct_effect') {
          if (old.actorId !== 'player' || old.effect?.id !== request.effectId)
            throw new Error('Operation ID already used for different direct effect');
          return { ...saved.summary, status: 'already_applied' };
        }
        const input = old.checkInput;
        if (!input || old.actorId !== 'player' || input.attribute !== request.attribute ||
            input.skill !== request.skill || input.sub !== request.sub || input.dc !== request.dc)
          throw new Error('Operation ID already used for different check input');
        return { ...saved.summary, status: 'already_applied' };
      }
      const expectedRevision = readTestSummary(opts).revision;
      if (request.kind === 'direct_effect')
        return settleDirectEffect({ ...opts, operationId, expectedRevision,
          actorId: 'player', effect: DIRECT_EFFECTS[request.effectId] });
      let prepared;
      try { prepared = this.prepareCheck(request, choiceId); }
      catch (error) { return { status: 'needs_input', missing: [error.message] }; }
      if (prepared.choices.length && choiceId === undefined)
        return { status: 'needs_choice', publicBasis: prepared.publicBasis, choices: prepared.choices };
      if (!prepared.choices.length && choiceId !== undefined)
        return { status: 'needs_input', missing: ['当前没有可用的主动选项'] };
      const dice = drawDice();
      if (!Array.isArray(dice)) throw new Error('Trusted dice source must return an array');
      return settleCheck({ ...opts, operationId, expectedRevision, actorId: 'player',
        trustedEffects: DIRECT_EFFECTS,
        checkInput: { attribute: request.attribute, skill: request.skill,
          ...(request.sub ? { sub: request.sub } : {}), dc: request.dc,
          ...(choiceId ? { effectChoice: choiceId } : {}), dice } });
    },
  };
}
